
(() => {
  const find = (win) => {
    for (let i = 0; i < 10 && win; i++) {
      try { if (win.API) return win.API; } catch { return null; }
      if (win.parent === win) break;
      win = win.parent;
    }
    return null;
  };
  let api = null;
  try { api = find(window) ?? (window.opener ? find(window.opener) : null); } catch { api = null; }
  if (api) {
    api.LMSInitialize('');
    window.addEventListener('beforeunload', () => api.LMSFinish(''));
    if (document.body.dataset.scoKind === 'quiz') {
      const st = api.LMSGetValue('cmi.core.lesson_status');
      if (st === 'not attempted' || st === '') api.LMSSetValue('cmi.core.lesson_status', 'incomplete');
    } else {
      api.LMSSetValue('cmi.core.lesson_status', 'completed');
    }
    api.LMSCommit('');
  }
  window.__reportQuiz = (scope, right, answered, total, pass) => {
    if (!api || answered < total) return;
    api.LMSSetValue('cmi.core.score.min', '0');
    api.LMSSetValue('cmi.core.score.max', String(total));
    api.LMSSetValue('cmi.core.score.raw', String(right));
    api.LMSSetValue('cmi.core.lesson_status', right >= pass ? 'passed' : 'failed');
    api.LMSCommit('');
  };
})();

document.addEventListener('click', (e) => {
  const btn = e.target.closest('button.quiz-check');
  if (!btn) return;
  const scope = btn.closest('section.page') ?? document.body;
  const questions = scope.querySelectorAll('fieldset.quiz-q');
  let right = 0;
  let answered = 0;
  questions.forEach((fs) => {
    fs.classList.remove('correct', 'wrong');
    fs.querySelectorAll('label').forEach((l) => l.classList.remove('is-answer'));
    const sel = fs.querySelector('input:checked');
    if (!sel) return;
    answered++;
    const ok = sel.closest('label').dataset.letter === fs.dataset.answer;
    if (ok) right++;
    fs.classList.add(ok ? 'correct' : 'wrong');
    if (!ok) {
      const good = fs.querySelector('label[data-letter="' + fs.dataset.answer + '"]');
      if (good) good.classList.add('is-answer');
    }
  });
  const total = questions.length;
  const pass = +btn.dataset.pass || 0;
  if (window.__reportQuiz) window.__reportQuiz(scope, right, answered, total, pass);
  const out = scope.querySelector('.quiz-result');
  out.hidden = false;
  out.classList.remove('pass', 'fail');
  if (answered < total) {
    out.textContent = 'Answered ' + answered + ' of ' + total + ' \u2014 answer every question, then check again.';
  } else if (right >= pass) {
    out.classList.add('pass');
    out.textContent = 'Score ' + right + '/' + total + ' \u2014 pass! (' + pass + '+ needed)';
  } else {
    out.classList.add('fail');
    out.textContent = 'Score ' + right + '/' + total + ' \u2014 below the pass mark (' + pass + '+ needed). Review the lesson and try again.';
  }
});
